import React from 'react'
import logo from '../../Assets/logo.png'
import { Link } from 'react-router-dom'
import axios from 'axios'

const Navbar = ({userData, authToken, setAuthToken, setUserData}) => {

  const logout = () => {
    axios.post("http://127.0.0.1:8000/api/logout", "", {
        headers: {
        "Authorization": 'Token ' + authToken
      }
    }).then(
      res => {
      console.log(res);
      setAuthToken('')
      setUserData({})
      localStorage.clear()
    }
    ).catch(err => console.log(err))
  }
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light shadow-sm " style={{height:'90px'}}>
      <div className="container" style={{width: '100%'}} >
        <Link to="/" className="navbar-brand" >
            <img src={logo} style={{position:'sticky',padding:'3px'}} height="60" alt="mb-logo" />
          </Link>

        <ul className="navbar-nav main-nav" >
          <li className="nav-item item">
            <Link to="/recipes" className="nav-link" >Recipe</Link>
          </li>
          
          <li className="nav-item item">
            <Link to="/aboutus" className="nav-link" >About Us</Link>
          </li>
          <li className="nav-item item">
            <Link to="/support" className="nav-link" >Support</Link>
          </li>
        </ul>
        {
        userData.user_name === undefined ?
        <ul className="navbar-nav not-auth">
          <li className="nav-item item">
            <Link to="/signIn" className="nav-link">Login </Link>
          </li>
          <li className="nav-item item">
            <Link to="/signUp" className="nav-link">Sign Up</Link>
          </li>
        </ul> :
        <ul className="navbar-nav sec-nav"  >
          <li className="nav-item item">
            <Link to="/feed" className="nav-link" >Feed</Link>
          </li>
          
          <li className="nav-item" >
            <Link to="/my-orders" className='nav-link' style={{paddingLeft:'10px', fontSize: '16px', fontWeight: 'normal',  width:'120px'}} >My Order</Link>
          </li>

          <li className="nav-item" >
            <Link to="/my-posts" className='nav-link' style={{paddingLeft:'10px', fontSize: '16px', fontWeight: 'normal',  width:'120px'}} >My Posts</Link>
          </li>

          <li className="nav-item" >
            <Link to="/profile" className='nav-link' style={{paddingLeft:'10px', fontSize: '16px', fontWeight: 'normal',  width:'120px'}} >Profile</Link>
          </li>

          <li className="nav-item" >
            <Link onClick={logout} className='nav-link' style={{paddingLeft:'10px', fontSize: '16px', fontWeight: 'normal',  width:'120px'}} >Logout</Link>
          </li>

          {/* <li className="nav-item" >
            <h6 style={{paddingLeft:'10px', width:'120px', marginTop: "10px" }} >Welcome {userData.user_name}!</h6>
          </li> */}
          
        </ul>
        } 

      </div>

    </nav >
  )
}

export default Navbar;
