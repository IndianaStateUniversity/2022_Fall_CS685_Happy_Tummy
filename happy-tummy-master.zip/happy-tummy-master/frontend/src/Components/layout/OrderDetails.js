import axios from 'axios';
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import ReactLoading from 'react-loading'

const OrderDetails = ({authToken}) => {
    const [orderData, setOrderData] = useState([])
    const [date, setDate] = useState()
    const {id} = useParams()
    const navigate = useNavigate()

    useEffect(() => {
        if (authToken == ''){
            navigate('/')
        }

        console.log(id);
        // id = 

        console.log("authToken", authToken);
        axios.get("http://127.0.0.1:8000/api/get/user-orders-all", {
            headers: {
            "Authorization": 'Token ' + authToken
        }})
        .then(res => {
            console.log(res.data.orders, id)
            console.log(res.data.orders[id])
            setOrderData(res.data.orders[id])
            setDate(new Date(res.data.orders[id].created_at))
        })
        .catch(err => console.log(err))
    }, [])

    return (
        <>
        {date !== undefined ?
        <div key={id} className="order-container" >
            <div style={{display:'flex', justifyContent : "space-between" }} >
                <h6 style={{textAlign: "center"}} >Order Id: {id}</h6>
                <p style={{textAlign: "center"}} >{`${date.getDate()}/${date.getMonth() +1 }/${date.getFullYear()} ${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`}</p>
            </div>
            {orderData.Ingredients.map(ing => {
                return (
                    <div className='ing-container' >
                        <p className='ing-desc' >Name: {ing.name}</p>
                        <p className='ing-desc'>Quantity: {ing.quantity + " " + ing.unit} </p>
                        <p className='ing-desc'>Price: {ing.price}</p>
                    </div>
                )
            })}
            <h6>Grand Total: {orderData.total_cost}</h6>
            {/* <button onClick={() => viewOrderDetails(id)} style={{margin:"5px auto"}} >View Details</button>     */}
        </div>
        : 
        <ReactLoading type={"spin"} width={"20%"} />
        }
        </>
    );
};

export default OrderDetails;