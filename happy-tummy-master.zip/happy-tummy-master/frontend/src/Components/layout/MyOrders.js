import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import "./myorders.css"

const MyOrders = ({authToken}) => {
    const [orderData, setOrderData] = useState([])
    const navigate = useNavigate()

    useEffect(() => {
        if (authToken == ''){
            navigate('/')
        }
        console.log("authToken", authToken);
        axios.get("http://127.0.0.1:8000/api/get/user-orders-all", {
            headers: {
            "Authorization": 'Token ' + authToken
        }})
        .then(res => {
            console.log(res.data.orders)
            setOrderData(res.data.orders)
        })
        .catch(err => console.log(err))
    }, [])

    const viewOrderDetails = (orderId) => {
        navigate("/my-orders/"+orderId)
    }

    return (
        <div style={{padding: "20px"}} >
            <h3 style={{textAlign: "center"}} >Order History</h3>
            <div style={{marginTop: "10px"}} >
                {
                    Object.keys(orderData).map(orderId => {
                        const date = new Date(orderData[orderId].created_at)
                        return (
                        <div key={orderId} className="order-container" >
                            <div style={{display:'flex', justifyContent : "space-between" }} >
                                <h6 style={{textAlign: "center"}} >Order Id: {orderId}</h6>
                                <p style={{textAlign: "center"}} >{`${date.getDate()}/${date.getMonth() +1 }/${date.getFullYear()} ${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`}</p>
                            </div>
                            
                            <h6>Grand Total: {orderData[orderId].total_cost}</h6>
                            <button onClick={() => viewOrderDetails(orderId)} style={{margin:"5px auto"}} >View Details</button>    
                        </div>)
                    })
                }
            </div>
        </div>
    );
};

export default MyOrders;