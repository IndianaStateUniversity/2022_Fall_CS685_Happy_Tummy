import React, { useEffect } from 'react'
import heart from '../../../Assets/heart.png'
import share from '../../../Assets/share.png'
import './CardComponent.css'
import { useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
const MyPostCard = ({data, authToken}) => {

    const navigate = useNavigate()
    const [likes, setLikes] = useState(0)
    const [showPopup, setShowPopup] = useState(false)

    const toggle = (e) => {
        const button = e.target
        if (button.classList.contains("liked")) {
            button.classList.remove("liked");
            axios.post("http://127.0.0.1:8000/api/unlike-post", {
                post_id: data.post_id
            }, {
                headers: {
                    "Authorization": 'Token ' + authToken
                }
            }).then(res => {
                console.log("unliked");
                console.log(res.data)
                setLikes(like => like-1)
            }).catch(err => console.log(err))
        } else {
            button.classList.add("liked");
            axios.post("http://127.0.0.1:8000/api/like-post", {
                post_id: data.post_id
            }, {
                headers: {
                    "Authorization": 'Token ' + authToken
                }
            }).then(res => {
                console.log("liked");
                setLikes(like => like+1)
                console.log(res.data)
            }).catch(err => console.log(err))
        }
    }

    const showDetails = () => {
        navigate('/feed/'+data.slug)
    }

    const changeVisibility = (e) => {
        const check = e.target.checked
        console.log(check);
        if (check) {
            axios.post("http://127.0.0.1:8000/api/post/access-all", {
                post_id: data.post_id
            },{
                headers: {
                    "Authorization": 'Token ' + authToken
                }
            }).then(res => {
                console.log(res.data);
            }).catch(err => console.log(err))
        }
        else{
            axios.post("http://127.0.0.1:8000/api/post/access-link", {
                post_id: data.post_id
            },{
                headers: {
                    "Authorization": 'Token ' + authToken
                }
            }).then(res => {
                console.log(res.data);
            }).catch(err => console.log(err))
        }
    }

    useEffect(() => {
        setLikes(data['likes'])

        axios.get("http://127.0.0.1:8000/api/post/liked", {
            headers: {
                "Authorization": 'Token ' + authToken
            },
            params: {
                post: data["post_id"]
            }               
        }).then(res => {
            // console.log(data['recipe_name'], res.data['has_liked']);
        console.log(data["post_id"], data["recipe_name"], res.data['has_liked']);

            const liked = res.data['has_liked']
            const btn = document.getElementById("heart"+data["post_id"])

            if (liked){
                btn.classList.add("liked");
                console.log("added", btn.classList);
            }
            else{
                if (btn.classList.contains("liked")) {
                    btn.classList.remove("liked");
                    console.log("removed", btn.classList);
                }
            }

            console.log(btn.classList);

        }).catch(err => console.log(err))

        const checkbox = document.getElementById("checkbox"+data["post_id"])
        if(data["link_only"]){
            checkbox.checked = false
        }
        else{
            checkbox.checked = true
        }


    }, [])

    return (
        <div className='container-card' style={{width:"30%", position: "relative"}} >
            <img className='feed-img' src={data.image_url} alt="" />
            <h5 className='feed-heading' style={{textAlign: "center"}} >{data.recipe_name}</h5>
            <div style={{display: "flex", justifyContent: "space-around" , marginTop: "20px"}} >
                <div style={{display: "flex"}}>
                    <span className="heart" id={"heart"+data.post_id} onClick={toggle} style={{transform: "scaleX(0.5) scaleY(0.5) rotate(-45deg)"}} ></span>
                    <p>{likes}</p>
                </div>
                <img className="share" onClick={(e) => setShowPopup(true) } src={share} style={{height: "25px", position: "inherit", marginLeft: "10px"}} />

                <div style={{display: "flex", marginLeft:"10px"}} >
                        <p style={{marginLeft:"5px", fontSize:"20px"}} >Show all</p>
                        <input id={"checkbox"+data.post_id} onChange={changeVisibility} style={{height: "25px", width: "25px", marginLeft: "5px"}} type="checkbox" name="accept" /> 
                </div>
                <button className='btn btn-secondary' onClick={showDetails} style={{}} >View details</button>
            </div>

            {showPopup &&
            <div className='popup' >
                <p style={{marginBottom: "10px"}} >{'http://localhost:3000/feed/'+data.slug}</p>
                <button onClick={(e) => setShowPopup(false)} className='btn btn-secondary' >Ok</button>
            </div>}
        </div>

    )
}
export default MyPostCard