import React, { useEffect } from 'react'
import heart from '../../../Assets/heart.png'
import share from '../../../Assets/share.png'
import './CardComponent.css'
import { useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
const Card = ({data, authToken}) => {

    const navigate = useNavigate()
    const [likes, setLikes] = useState(0)

    const toggle = (e) => {
        const button = e.target
        if (button.classList.contains("liked")) {
            button.classList.remove("liked");
            axios.post("http://127.0.0.1:8000/api/unlike-post", {
                post_id: data.post_id
            }, {
                headers: {
                    "Authorization": 'Token ' + authToken
                }
            }).then(res => {
                console.log(res)
                setLikes(like => like - 1)
            }).catch(err => console.log(err))
        } else {
            button.classList.add("liked");
            axios.post("http://127.0.0.1:8000/api/like-post", {
                post_id: data.post_id
            }, {
                headers: {
                    "Authorization": 'Token ' + authToken
                }
            }).then(res => {
                console.log(res)
                setLikes(like => like + 1)
            }).catch(err => console.log(err))
        }
    }

    const showDetails = () => {
        navigate('/feed/'+data.slug)
    }

    useEffect(() => {
        setLikes(data['likes'])
        axios.get("http://127.0.0.1:8000/api/post/liked", {
            headers: {
                "Authorization": 'Token ' + authToken
            },
            params: {
                post: data["post_id"]
            }               
        }).then(res => {
            // console.log(data['recipe_name'], res.data['has_liked']);
        console.log(data["post_id"], data["recipe_name"], res.data['has_liked']);

            const liked = res.data['has_liked']
            const btn = document.getElementById("heart"+data["post_id"])

            if (liked){
                btn.classList.add("liked");
                console.log("added", btn.classList);
            }
            else{
                if (btn.classList.contains("liked")) {
                    btn.classList.remove("liked");
                    console.log("removed", btn.classList);
                }
            }

            console.log(btn.classList);

        }).catch(err => console.log(err))
    }, [])

    return (
        <div className='container-card' >
            <img className='feed-img' src={data.image_url} alt="" />
            <h5 className='feed-heading' style={{textAlign: "center"}} >{data.recipe_name}</h5>
            <div style={{display: "flex", justifyContent: "space-around" , marginTop: "20px"}} >
                <div style={{display: "flex"}}>
                    <span className="heart" id={"heart"+data.post_id} onClick={toggle} style={{transform: "scaleX(0.5) scaleY(0.5) rotate(-45deg)"}} ></span>
                    <p>{likes}</p>
                </div>
                <img className="share" src={share} style={{height: "25px", position: "inherit", marginLeft: "10px"}} />
                <button className='btn btn-secondary' onClick={showDetails} style={{}} >View details</button>
            </div>
        </div>

    )
}
export default Card