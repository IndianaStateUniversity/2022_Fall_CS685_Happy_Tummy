import axios from 'axios';
import React, {useState} from 'react'
import { Cardreceipe } from './receipecards';

const SearchBar = ({setCardsData}) => {
    const search = () => {
        var input1 = document.getElementById('searchbar').value
        input1 = input1.toLowerCase();
        console.log(input1);
        setCardsData([])
        axios.post("http://localhost:8000/api/query-recipes", {query:input1})
        .then(res => {
            setCardsData(res.data.recipes)
            console.log(res);
        })
        .catch(err => console.log(err))
        }

    
    return (
        <div style={{ display: 'flex', flexDirection: 'column', marginTop: '1rem' }}>
            <div style={{ display: 'flex', height: '40px', width: '600px', margin: '10px', }}>
                <input id='searchbar' type="text" placeholder='search... ' style={{ flex: 5, borderRadius: '12px', padding: '10px', zIndex: "1" }} />
                <button onClick={search} style={{ flex: 1, marginLeft: '10px', backgroundColor: '#0096FF', color: '#fff', borderRadius: '12px', zIndex: "1" }} >Click me</button>
            </div>
            {
                
            }
        </div>



    )
        }

export default SearchBar