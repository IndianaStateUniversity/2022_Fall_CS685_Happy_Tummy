import React from 'react'

const Footer = () => {
  return (
    <div style={ {position: 'fixed', bottom:0, right:0, paddingRight:'30px'} }>
      <p>@HappyTummy2022</p>
    </div>
  )
}

export default Footer
