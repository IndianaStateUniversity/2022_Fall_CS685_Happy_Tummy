import React from 'react'
import { UserCard } from 'react-ui-cards';
import dp1 from '../Assets/dp1.png'
import dp2 from '../Assets/dp2.png'
import dp3 from '../Assets/dp3.jpeg'
import dp4 from '../Assets/dp4.jpg'

export const User1 = () => <UserCard
    float
    href='https://www.linkedin.com/in/abhigna-reddy'
    header={dp1}
    name='Abhigna'
    positionName='Graduate Student in Computer Science'
/>

export const User2 = () => <UserCard
    float
    href='https://www.linkedin.com/in/gaurang-pai-palondicar'
    header={dp2}
    name='Gaurang'
    positionName='Graduate Student in Computer Science'
/>

export const User3 = () => <UserCard
    float
    href='https://www.linkedin.com/in/mounika-sure'
    header={dp3}
    name='Mounika'
    positionName='Graduate Student in Computer Science'
/>

export const User4 = () => <UserCard
    float
    href='https://www.linkedin.com/in/mgopisainath7'
    header={dp4}
    name='Sainath'
    positionName='Graduate Student in Computer Science'
/>

const AboutUs = () => {
  return (
    <div>
        <h3 className="text-center" style={{marginTop: '30px'}}>About Us</h3>
   
      <div style={{display:'flex', width:'100%', justifyContent:'center'}}>
        <User1 />
        <User2 />
        <User3 />
        <User4 />
      </div>
    
        <br/>
        <h4 className="text-center">We are the Students of Indiana State University</h4>

    </div>   
    
  )
  
}

export default AboutUs
