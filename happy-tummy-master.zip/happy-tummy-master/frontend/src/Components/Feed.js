import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import Card from './layout/feedcards/Card';

const Feed = ({authToken}) => {

  const [feedData, setFeedData] = useState([])
  const navigation = useNavigate()

  const handleCreate = () => {
    navigation('/create-post')
  }

  useEffect(() => {
    axios.get("http://127.0.0.1:8000/api/feed", {
      headers: {
        "Authorization": 'Token ' + authToken
      },
      params: {
        page: 1
      }
    }).then(res => {
      setFeedData(res.data)
      console.log("feed data", res.data);

    }).catch(err => {
      console.log(err);
    })
  }, [])



  return (
    <div>
      <div style={{display:"flex",justifyContent:'center',alignItems:'center', marginTop: "20px", zIndex:'1'}} >
            <button onClick={handleCreate} className='btn btn-primary create-btn' >Create your post</button>
      </div>
      <div>
      {   feedData.results &&
          feedData.results.map((feed) => (
                  <div key={feed.post_id}>
                    <Card key={feed.post_id} data={feed} authToken={authToken} />
                  </div>
                ))
      }
      </div>
    </div>
  );
}

export default Feed
