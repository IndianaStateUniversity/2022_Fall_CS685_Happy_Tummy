import React, {useEffect, useState} from 'react'
import ReactLoading from 'react-loading'

import { Cardreceipe } from './layout/receipecards'
import SearchBar from './layout/SearchBar'
import image from '../Assets/offer2.png'
import axios from 'axios'
const Recipe = ({cardsData, setCardsData}) => {

  return (
    <div style={{
      width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0px',
      margin: '0px',
    }}>

      <SearchBar setCardsData={setCardsData} />

      { cardsData.length != 0 ?
      <div style={{
        display: 'flex',
        flexWrap: 'wrap',
        flexDirection: 'row',
        padding: '0px',
        margin: '2rem 0 0 0',
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center'
      }} >

        {cardsData.map((x) => (
          <Cardreceipe key={x.name} data={x} />
        ))}
      </div>
      :
          <div style={{marginTop: "5rem"}} >
            <h4 style={{marginBottom: "2rem"}} >Searching best recipes for you</h4>
            <ReactLoading type={"spin"} color={"#000000"} width={'14rem'} />
          </div>
      }
    </div>
  )
}

export default Recipe
