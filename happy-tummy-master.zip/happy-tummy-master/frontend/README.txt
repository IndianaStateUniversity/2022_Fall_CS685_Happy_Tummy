Install React Framework
1) Open folder on VS Code

2) Open Terminal using Ctrl and ` and run the command
   npm install react-scripts --save
3)npm install --save react-ui-cards
4) npm install --save react-faq-component

5) Upon seeing node modules folder, run the command
   npm start